// Árvore AVL implementada em um heap alocado na superclasse

public class ArvAvl extends ArvBin {
    private int len;
    private int removed;

    public ArvAvl(int len) {
        super(len);
        this.len = len;
    }

    public void insert(String value) {    
        super.insert(value);
        int position = findPosition(value, 0);
        int save = position;
        int fb = height(nodeLeft(position)) - height(nodeRight(position));
        
        while(position >= 0) {
            fb = height(nodeLeft(position)) - height(nodeRight(position));
            if(fb == 2 || fb == -2)
                break;

            if(position == 0)
                position = -1;
            else
                position = nodeDad(position);
        }

        if(position >= 0) {
            // Heap auxiliar
            String[] newHeap = new String[len];
            for(int i = 0; i < len; i++) {
                newHeap[i] = arvBin[i];
            }

            // Rotação à direita predomina
            if(fb == 2) {
                if(arvBin[save].compareTo(arvBin[nodeLeft(position)]) < 0)
                    rightRotate(newHeap, position);
                else {
                    leftRotate(newHeap, nodeLeft(position));
                    rightRotate(newHeap, position);
                }
            }
            else {
                if(arvBin[save].compareTo(arvBin[nodeRight(position)]) > 0)
                    leftRotate(newHeap, position);
                else {
                    rightRotate(newHeap, nodeRight(position));
                    leftRotate(newHeap, position);
                }
            }

        }
    }

    private void leftRotate(String[] heap, int a) {
        int b = nodeRight(a);

        int esquerda = nodeLeft(a);
        String old = getNode(esquerda);

        heap[esquerda] = arvBin[a];
        heap[a] = "";

        desceNos(nodeLeft(esquerda), old, heap, -1);
        copiaSubB(heap, nodeRight(esquerda), nodeLeft(b));

        heap[a] = heap[b];
        heap[b] = "";

        fixTree(heap, nodeRight(b));

        for(int i = 0; i < len; i++) {
            arvBin[i] = heap[i];
        }
    }

    // a é o nó no qual será centrada a rotação à direita
    private void rightRotate(String[] heap, int a) {
        int b = nodeLeft(a);
        // Filho direito de a
        int direita = nodeRight(a);
        // String do filho direito de a
        String old = getNode(direita);
        // Troca String do filho pela string de a (desce o a)
        heap[direita] = arvBin[a];
        heap[a] = "";

        desceNos(nodeRight(direita), old, heap, 1);
        copiaSubB(heap, nodeLeft(direita), nodeRight(b));

        heap[a] = heap[b];
        heap[b] = "";

        fixTreeRight(heap, nodeLeft(b));

        for(int i = 0; i < len; i++) {
            arvBin[i] = heap[i];
        }
    }

    public void fixTree(String[] heap, int son) {
        int dad = nodeDad(son);

        if(heap[son] == "")
            return;

        if(son == (2*dad + 1)) {
            heap[dad - 1] = heap[son];
            heap[son] = "";
        }
        else {
            heap[dad] = heap[son];
            heap[son] = "";
        }

        fixTree(heap, nodeLeft(son));
        fixTree(heap, nodeRight(son));
    }

    public void fixTreeRight(String[] heap, int son) {
        int dad = nodeDad(son);

        if(heap[son] == "")
            return;

        if(son == (2*dad + 1)) {
            heap[dad] = heap[son];
            heap[son] = "";
        }
        else {
            heap[dad + 1] = heap[son];
            heap[son] = "";
        }

        fixTreeRight(heap, nodeLeft(son));
        fixTreeRight(heap, nodeRight(son));
    }

    private void copiaSubB(String[] heap, int destino, int origem) {
        if(arvBin[origem] == "")
            return;

        heap[destino] = arvBin[origem];
        heap[origem] = "";

        copiaSubB(heap, nodeLeft(destino), nodeLeft(destino));
        copiaSubB(heap, nodeRight(destino), nodeRight(destino));
    }

    private void desceNos(int novoNo, String old, String[] heap, int flow) {
        if(old.equals(""))
            return;

        String newOld = getNode(novoNo);

        heap[novoNo] = old;

        if(flow == 1) {
            corrigeEsquerda(heap, novoNo, nodeLeft(nodeDad(novoNo)), nodeLeft(novoNo));
            desceNos(nodeRight(novoNo), newOld, heap, 1);
        }
        else {
            corrigeDireita(heap, novoNo, nodeRight(nodeDad(novoNo)), nodeRight(novoNo));
            desceNos(nodeLeft(novoNo), newOld, heap, -1);
        }
    }

    private void corrigeEsquerda(String[] heap, int filho, int esqPai, int esqFilho) {
        if(arvBin[esqPai] == "")
            return;

        heap[esqFilho] = arvBin[esqPai];
        heap[esqPai] = "";

        corrigeEsquerda(heap, filho, nodeLeft(esqPai), nodeLeft(esqFilho));
        corrigeEsquerda(heap, filho, nodeRight(esqPai), nodeRight(esqFilho));
    }

    private void corrigeDireita(String[] heap, int filho, int dirPai, int dirFilho) {
        if(arvBin[dirPai] == "")
            return;

        heap[dirFilho] = arvBin[dirPai];
        heap[dirPai] = "";

        corrigeEsquerda(heap, filho, nodeLeft(dirPai), nodeLeft(dirFilho));
        corrigeEsquerda(heap, filho, nodeRight(dirPai), nodeRight(dirFilho));
    }

    // Remove uma string da Heap
    public boolean remove(String v) {
        int position = findPosition(v, 0);

        System.out.println(position);

        if(position == -1)
            return false;
        
        if(getNode(nodeLeft(position)) == "" || getNode(nodeRight(position)) == "")
            removed = position;
        else {
            removed = nodeLeft(position);

            while(arvBin[nodeRight(removed)] != "")
                removed = nodeRight(removed);
        }

        return super.remove(v);
    }

    public void balance() {
        int fb = height(nodeLeft(removed)) - height(nodeRight(removed));
        while(removed >= 0) {
            fb = height(nodeLeft(removed)) - height(nodeRight(removed));

            if(fb == -2 || fb == 2)
                break;

            if(removed == 0) {
                removed = -1;
                continue;
            }

            removed = nodeDad(removed);
        }

        System.out.println(fb);
        System.out.println(removed);

        if(removed >= 0) {
            String[] newHeap = new String[len];
            for(int i = 0; i < len; i++) {
                newHeap[i] = arvBin[i];
            }

            int filho;
            // Rotação à direita predomina
            if(fb == 2) {
                filho = nodeLeft(removed);
                filho = height(nodeLeft(filho)) - height(nodeRight(filho));
                if(filho >= 0)
                    rightRotate(newHeap, removed);
                else {
                    leftRotate(newHeap, nodeLeft(removed));
                    rightRotate(newHeap, removed);
                }
            }
            else {
                filho = nodeRight(removed);
                filho = height(nodeLeft(filho)) - height(nodeRight(filho));
                if(filho <= 0)
                    leftRotate(newHeap, removed);
                else {
                    rightRotate(newHeap, nodeRight(removed));
                    leftRotate(newHeap, removed);
                }
            }
        }
    }

    // Verifica se elemento está na Heap
    public boolean find(String v) {
        return super.find(v);
    }

    public int findPosition(String v, int position) {
        return super.findPosition(v, position);
    }

    // Retorna o número de elementos da Heap
    public int len() {
        return super.len();
    }

    protected int nodeDad(int i) {
        return super.nodeDad(i);
    }

    // Retorna o número do filho à esquerda
    protected int nodeLeft(int i) {
        return super.nodeLeft(i);
    }

    // Retorna o número do filho à direita
    protected int nodeRight(int i) {
        return super.nodeRight(i);
    }

    // Atribui uma string ao elemento de índice i
    // da Heap
    protected void setNode(int i, String v) {
        super.setNode(i, v);
    }

    // Retorna a string do elemento de índice i
    // da Heap
    protected String getNode(int i) {
        return super.getNode(i);
    }

    // Retorna o número de nós de uma árvore
    // de raiz i
    protected int countheap(int i) {
        return super.countheap(i);
    }

    // Calcula a altura de um nó
    private int height(int position) {
        if(arvBin[position] == "")
            return -1;

        int ha = height(nodeLeft(position));
        int hb = height(nodeRight(position));

        if(ha > hb)
            return 1 + ha;
        else
            return 1 + hb;
    }

    // Retorna um string no formato de um grafo
    public String toString() {
        return super.toString();
    }

    // Verifica se a árvore está balanceada
    protected boolean isBalance() {
        return isBalanceAux(0);
    }

    protected boolean isBalanceAux(int position) {
        if(arvBin[nodeLeft(position)] == "" && arvBin[nodeRight(position)] == "")
            return true;

        int leftHeight = height(position);
        int rightHeight = height(position);
        int diff = leftHeight - rightHeight;

        if(Math.abs(diff) <= 1 && isBalanceAux(nodeLeft(position)) && isBalanceAux(nodeRight(position)))
            return true;

        return false;
    }
}
