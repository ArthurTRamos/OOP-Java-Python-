// Árvore de busca não balanceada com heap (Superclasse)
// Raiz: índice 0
// Filhos do nó de índice i: índices (2*i + 1) e (2*i + 2)

public class ArvBin {
    protected String[] arvBin; // Vetor de strings da árvore

    // Construtor da Classe da Heap de tamanho len
    public ArvBin(int len) {
        arvBin = new String[len];

        for(int i = 0; i < len; i++) {
            arvBin[i] = "";
        }
    }

    // Insere uma string value na Heap
    public void insert(String value) {   
        if(!find(value))  {
            insertAux(value, 0);
        }
    }

    public void insertAux(String value, int position) {
        if(arvBin[position] == "")
            arvBin[position] = value;

        else {
            if(value.compareTo(arvBin[position]) > 0)
                insertAux(value, nodeRight(position));
            else
                insertAux(value, nodeLeft(position));
        }
    }

    // Remove uma string v da Heap
    public boolean remove(String v) {
        int postion = findPosition(v, 0);

        if(postion == -1)
            return false;

        int left = nodeLeft(postion);
        int right = nodeRight(postion);

        // Se o nó tiver 0 ou 1 filho
        if(arvBin[left] == "" || arvBin[right] == "") {
            if(arvBin[left] != "") {
                arvBin[postion] = arvBin[left];
                arvBin[left] = "";
                fixTree(nodeLeft(left));
                fixTree(nodeRight(left));
                return true;
            }

            if(arvBin[right] != "") {
                arvBin[postion] = arvBin[right];
                arvBin[right] = "";
                fixTree(nodeLeft(right));
                fixTree(nodeRight(right));
                return true;
            }

            arvBin[postion] = "";
            return true;
        }
        else {
            int biggestLeft = left;

            while(arvBin[nodeRight(biggestLeft)] != "") {
                biggestLeft = nodeRight(biggestLeft);
            }

            arvBin[postion] = arvBin[biggestLeft];
            arvBin[biggestLeft] = "";
            fixTree(nodeLeft(biggestLeft));
            return true;
        }
    }

    public void fixTree(int son) {
        int dad = nodeDad(son);

        if(arvBin[son] == "")
            return;

        if(son == (2*dad + 1)) {
            arvBin[dad] = arvBin[son];
            arvBin[son] = "";
        }
        else {
            arvBin[dad] = arvBin[son];
            arvBin[son] = "";
        }

        fixTree(nodeLeft(son));
        fixTree(nodeRight(son));
    }

    // Verifica se elemento está na Heap
    public boolean find(String v) {
        return(findAux(v, 0));
    }

    public boolean findAux(String v, int position) {
        if(arvBin[position] == "")
            return false;
        
        if(v.equals(arvBin[position]))
            return true;

        else {
            if(v.compareTo(arvBin[position]) > 0)
                return(findAux(v, nodeRight(position)));
            else
                return(findAux(v, nodeLeft(position)));
        }
    }

    public int findPosition(String v, int position) {
        if(arvBin[position] == "")
            return -1;
        
        if(v.equals(arvBin[position]))
            return position;

        else {
            if(v.compareTo(arvBin[position]) > 0)
                return(findPosition(v, nodeRight(position)));
            else
                return(findPosition(v, nodeLeft(position)));
        }
    }

    // Retorna o número de elementos da Heap
    public int len() {
        return(lenAux(0));
    }

    public int lenAux(int position) {
        if(arvBin[position] == "")
            return 0;

        return 1 + lenAux(nodeLeft(position)) + lenAux(nodeRight(position));
    }

    // Retorna o número do pai
    protected int nodeDad(int i) {
        return (i-1)/2;
    }

    // Retorna o número do filho à esquerda
    protected int nodeLeft(int i) {
        return 2*i + 1;
    }

    // Retorna o número do filho à direita
    protected int nodeRight(int i) {
        return 2*i + 2;
    }

    // Atribui uma string ao elemento de índice i
    // da Heap
    protected void setNode(int i, String v) {
        arvBin[i] = v;
    }

    // Retorna a string do elemento de índice i
    // da Heap
    protected String getNode(int i) {
        return(arvBin[i]);
    }

    // Retorna o número de nós de uma árvore
    // de raiz i
    protected int countheap(int i) {
        return(lenAux(i));
    }

    // Retorna um string no formato de um grafo
    public String toString() {
        String arv = new String("digraph {\n");
        int i, counter, left, right;
        String newLine;

        i = counter = 0;

        while(counter < len()) {
            if(arvBin[i].equals("")) {
                i++;
                continue;
            }

            left = nodeLeft(i);
            right = nodeRight(i);

            if(!(arvBin[left].equals(""))) {
                newLine = String.format("\"%d %s\" " +
                                        "->" +
                                        "\"%d %s\"\n",
                                        i, arvBin[i], left, arvBin[left]);
                arv = arv.concat(newLine);
            }

            if(!(arvBin[right].equals(""))) {
                newLine = String.format("\"%d %s\" " +
                                              "->" +
                                              "\"%d %s\"\n",
                                              i, arvBin[i], right, arvBin[right]);
                arv = arv.concat(newLine);
            }

            counter++;
            i++;
        }

        arv = arv.concat("}\n");

        return arv;
    }

    // Verifica se a árvore está balanceada
    protected boolean isBalance() {
        return true;
    }
}