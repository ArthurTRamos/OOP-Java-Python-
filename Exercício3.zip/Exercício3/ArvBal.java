// Árvore de busca perfeitamente balanceada usando heap da
// superclasse

import java.util.ArrayList;

public class ArvBal extends ArvBin {
    private int len;

    public ArvBal(int len) {
        super(len);
        this.len = len;
    }

    // Insere uma string na Heap
    @Override
    public void insert(String value) {
        super.insert(value);
        balance();
    }

    private void fillSorted(ArrayList<String> sorted, int position) {
        if(arvBin[position] != "") {
            fillSorted(sorted, nodeLeft(position));
            sorted.add(arvBin[position]);
            fillSorted(sorted, nodeRight(position));
        }
    }

    private void fillNewHeap(ArrayList<String> sorted, String[] newHeap, int a, int b, int dad) {
        if(a > b)
            return;
        
        int mid = (a+b)/2;
        newHeap[dad] = sorted.get(mid);

        fillNewHeap(sorted, newHeap, a, mid - 1, nodeLeft(dad));
        fillNewHeap(sorted, newHeap, mid + 1, b, nodeRight(dad));
    }

    // Remove uma string da Heap
    public boolean remove(String v) {
        return super.remove(v);
    }

    public void balance() {
        if(!isBalance()) {
            ArrayList<String> sortedList = new ArrayList<String>();
            String[] newHeap = new String[len];

            fillSorted(sortedList, 0);
            for(int i = 0; i < len; i++)
                newHeap[i] = "";

            fillNewHeap(sortedList, newHeap, 0, sortedList.size() - 1, 0);

            for(int i = 0; i < len; i++)
                arvBin[i] = newHeap[i];
        }
    }

    // Verifica se elemento está na Heap
    public boolean find(String v) {
        return super.find(v);
    }

    // Retorna o número de elementos da Heap
    public int len() {
        return super.len();
    }

    // Retorna o número do filho à esquerda
    protected int nodeLeft(int i) {
        return super.nodeLeft(i);
    }

    // Retorna o número do filho à direita
    protected int nodeRight(int i) {
        return super.nodeRight(i);
    }

    // Atribui uma string ao elemento de índice i
    // da Heap
    protected void setNode(int i, String v) {
        super.setNode(i, v);
    }

    // Retorna a string do elemento de índice i
    // da Heap
    protected String getNode(int i) {
        return super.getNode(i);
    }

    // Retorna o número de nós de uma árvore
    // de raiz i
    protected int countheap(int i) {
        return super.countheap(i);
    }

    // Retorna um string no formato de um grafo
    public String toString() {
        return super.toString();
    }

    // Verifica se a árvore está balanceada
    protected boolean isBalance() {
        return isBalanceAux(0);
    }

    protected boolean isBalanceAux(int position) {
        if(arvBin[nodeLeft(position)] == "" && arvBin[nodeRight(position)] == "")
            return true;
        
        int countLeft = countheap(nodeLeft(position));
        int countRight = countheap(nodeRight(position));
        int diff = Math.abs(countLeft - countRight);

        if(diff <= 1 && isBalanceAux(nodeLeft(position)) && isBalanceAux(nodeRight(position)))
            return true;

        return false;
    }
}
